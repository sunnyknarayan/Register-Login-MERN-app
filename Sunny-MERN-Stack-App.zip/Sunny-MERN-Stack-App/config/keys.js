module.exports = {
  mongoURI: "mongodb+srv://sunnyDB:<testDB>@cluster0.fugeh.mongodb.net/<sunnyApp>?retryWrites=true&w=majority",
  secretOrKey: "secret"
};
